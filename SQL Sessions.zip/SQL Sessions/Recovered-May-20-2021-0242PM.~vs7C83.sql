create database bankingDB

use bankingDB
drop table accountsinfo
create table accountsinfo1 (accountnumber int)
create table accountsInfo
(
	accNo int,
	accName varchar(20) not null,
	accType varchar(20) not null,
	accBalance int not null,
	accEmail varchar(20),
	accContactNo float,

	constraint pk_acNo primary key(accNo),
	constraint chk_accType check (accType in ('Saving','Brokerage','Credit')),
	constraint chk_accBalance check(accBalance > 500),
	constraint unk_accEmail unique (accEmail),
	constraint unk_accContatNo unique (accContactNo)
)
insert into accountsInfo values(101,'Richard','Saving',900,'richard@gmail.com',898956)
insert into accountsInfo(accNo,accType,accEmail,accContactNo) values (102,'Credit','someone@gmail.com',6989)

select * from accountsInfo
drop table accountsInfo


create table transactions (
					from_accNo int,
					to_accNo int,
					amount int,
					constraint pk_acNo primary key(from_accNo))


--------------------------------------------------------------------
--Foreign Key demo
-- create a parent table
	create table branchInfo
	(
		branchNo int,
		branchName varchar(20),
		branchCity varchar(20),
		branchContact float,
		constraint pk_branchNo primary key(branchNo)
	)
	insert into branchInfo values(101,'Abc','Texas',9000)
	insert into branchInfo values(102,'XYZ','NYK',1500)
	insert into branchInfo values(103,'PQR','California',6300)
	create table accountInformation
	(
		accNo int,
		accName varchar(20),
		accType varchar(20),
		accBalance float,
		accBranch int,
		constraint fk_accBranch foreign key(accBranch) references branchInfo
	)

	insert into accountInformation values(501,'Ronnie','Savings',12000,103)
	insert into accountInformation(accNo, accName, accType,accBalance) values (502,'Zyan','Savings',4000)
	insert into accountInformation(accNo, accName, accType,accBalance) values (503,'Zyan 2','Checking',4000)
	insert into accountInformation(accNo, accName, accType,accBalance) values (504,'Zyan 3','Credit',4000)
	delete from accountInformation

	select * from accountInformation

	alter table accountInformation alter column accBranch int not null

