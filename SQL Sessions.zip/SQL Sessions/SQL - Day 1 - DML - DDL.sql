--DQL -  DML 

--1
--select all the data from table, all columns and all rows
select * from EmployeeInfo

--2
---select limited columns
select empName,empDesignation from EmployeeInfo

--3
-- select with column alias
select empNo as [Employee Number],
	   empName as [Employee Name],
	   empDesignation as [Working As],
	   empSalary as [Monthly Pay]
from EmployeeInfo

--4
--select with concatination
select empName + ' Works as ' + empDesignation as [Employee Description] from EmployeeInfo


--5
--select with calculation
select empName as Name,
       empSalary as [Monthly Pay],
       empSalary * 12 as [Annual Pay],
       empSalary * 0.1 as Bonus,
       (empSalary * 12) * 0.05 as Tax
 	from employeeInfo


--6 select with string function	 
select empName as Normal,
      upper(empName) as UpperCase,
      lower(empName) as lowerCase,
      left(empName,2) as LeftSide,
      right(empName,2) as RightSide
	from employeeInfo

--7 select with concat function
	select CONCAT('Hi ',empName,' How is your job as a ',empDesignation) from EmployeeInfo

select * from EmployeeInfo

	nick.sa@myorg.com
	michell.di@myorg.com

	
		Try the below

		we wish to see the email address of all the employees
		
		empName.first2charactersofDesignation@myorg.com

		Make sure the whole email address is in small case
		column heading should be Email Address


		select lower(concat(empName,'.',left(empDesignation,2),'@myorg.com')) as [Email Address] from EmployeeInfo

--7 select with date functions
	select GETDATE() 
	select DATEPART(MONTH,getdate())
	select DATEPART(MONTH,'2022-09-09')

--8
--sort the data - Order by clause
	select * from EmployeeInfo order by empSalary desc

--9
--filter the data -- where clause
	select * from EmployeeInfo where empSalary > 8000 and  empName= 'Raj'

-----------------------------------------------------------------------------------------------------------
--	DML Data Manipulation Language -- Insert, update, delte

	--insert
		insert into EmployeeInfo values(105,'Price','Manager',8900)
		insert into EmployeeInfo values(106,'David','HR',15000)
		insert into EmployeeInfo values(107,'Drake','Sales',9000)
	--update 
		update EmployeeInfo set empSalary = empSalary + 250
		update EmployeeInfo set empSalary = empSalary + 300 where empDesignation = 'Sales'
		update EmployeeInfo set empName = 'Dear ' + empName
	--delte
		delete from EmployeeInfo where empNo > 101
		delete from EmployeeInfo where empSalary > 25000
		delete from EmployeeInfo where empDesignation = 'Manager'
	-----------------------------------------------------------------------------
	DDL

	create table AccountInfo
	(
		accNo int,
		accName varchar(20),
		accType varchar(20),
		accBalance int,
		constraint pk_accNo primary key(accNo)
	) 

	--incase after some time, if we wish to add new column, change  datatype
		

		alter table accountInfo add  accEmail varchar(40)

		alter table accountinfo add constraint chk_accName_min_3char check  (len(accName) > 3)

		alter table accountinfo add constraint chk_accBalance_range check(accBalance between 500 and 25000)

	insert into AccountInfo values(10,'Rocky','Savings',2000,'rocky@gmail.com')
	insert into AccountInfo values(20,'ria','Savings',2000,'rocky@gmail.com')

	--drop 
		drop table AccountInfo
	--trucate 
		truncate table AccountInfo 
