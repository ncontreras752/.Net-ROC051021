	create table deptInfo(
    deptNo int,
    deptName varchar(20),
    deptLocation varchar(20),
    depHead varchar(20),

    constraint dp_depNo primary key(deptNo)
)

insert into deptInfo (deptNo,deptName,deptLocation,depHead)

Values
(1,'Accounting', 'NYC','Mark'),
(2,'HR', 'Dallas','Mary'),
(3,'Production', 'San Fransisco','Marcos'),
(4,'Marketing', 'Florida','Angela'),
(5,'Sales', 'California','Jason')

create table  employeeInfo(
    empNo int,
    empName varchar(20),
    empDesignation varchar(20),
    empSalary float, 
    empDept int,

    constraint emp_empNo primary key(empNo),
    constraint fk_empDep foreign key (empDept) references deptInfo
)

insert into employeeInfo (empNo, empName , empDesignation , empSalary, empDept )

Values
(21,'Mark','Accountant', 200000, 1),
(22,'Angelos','Accountant', 50000, 1),
(23,'Joseph','Accountant', 50000, 1),

(24,'Marcos','HR', 50000, 2),
(30,'Jessica','HR', 50000, 2),
(25,'Mary','HR', 200000, 2),

(26,'Marcos','Developer', 200000, 3),
(27,'Delvon','Developer', 50000, 3),
(28,'Andrew','Developer', 50000, 3),

(29,'Thomas','Market Analyst', 200000, 4),
(31,'Nick','Marketing', 50000, 4),
(32,'Mark','Marketing', 50000, 4),

(33,'Chris','Sales Analyst ', 50000, 5),
(34,'Jorge','Sales manager', 200000, 5),
(35,'Jose','Sales', 50000, 5)


select * from deptInfo, employeeInfo where empNo = 22
select count(*) from deptInfo -- 5
select count(*) from employeeInfo -- 75

--lets saybank wants to launch a new credit cards for the people  having salary more than 50,000 
--and working as sales in San Fransisco

select count(*) from deptInfo, employeeInfo where empSalary > 50000 and deptLocation = 'San Fransisco'

select * from 
deptInfo 
full join 
employeeInfo
on
deptInfo.deptNo = employeeInfo.empDept
where  employeeInfo.empDept is null

select CONCAT('Dear ',employeeInfo.empName,' works as ',employeeInfo.empDesignation,' in ',deptInfo.deptName,' located in ',deptInfo.deptLocation) 
from employeeInfo join deptInfo
on employeeInfo.empDept = deptInfo.deptNo


select lower(concat(employeeInfo.empName,'.',left(employeeInfo.empDesignation,2),'@myorg.co.',left(deptInfo.deptLocation,2)))
from employeeInfo join deptInfo
on employeeInfo.empDept = deptInfo.deptNo

select count(*) from employeeInfo 
join deptInfo
on employeeInfo.empDept = deptInfo.deptNo
where deptLocation = 'California'

select sum(empSalary) from employeeInfo 
join deptInfo
on employeeInfo.empDept = deptInfo.deptNo
where deptLocation = 'California'

select * from deptInfo

insert into deptInfo values(6,'IT','Mexico','Jorge')
insert into deptInfo values(7,'Training','Reston','Bery')
insert into deptInfo values(8,'Finance','Vegas','Nilmo')

select * from employeeInfo where empDept = 8
select * from deptInfo  left join employeeInfo on deptInfo.deptNo = employeeInfo.empDept


select count(employeeInfo.empNo) As Total, deptInfo.deptLocation from 
	deptInfo  left join employeeInfo on deptInfo.deptNo = employeeInfo.empDept
	group by deptLocation order by Total desc

select * from employeeInfo
insert into employeeInfo(empNo,empname,empDesignation,empSalary) values(36,'Arti','Manager',45000)
insert into employeeInfo(empNo,empname,empDesignation,empSalary) values(37,'Priya','Manager',45000)
insert into employeeInfo(empNo,empname,empDesignation,empSalary) values(38,'Raj','Manager',45000)
insert into employeeInfo(empNo,empname,empDesignation,empSalary) values(39,'Sheldon','Manager',45000)
insert into employeeInfo(empNo,empname,empDesignation,empSalary) values(40,'Penny','Manager',45000)