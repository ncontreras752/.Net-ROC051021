create database SalesDB

use SalesDB

create table ProductMaster
(
	productId int primary key,
	productCategory varchar(20),
	productName varchar(20),
	productTax int
)

insert into ProductMaster values(1,'Cold-Drinks','Coke',10)
insert into ProductMaster values(2,'Hot-Drinks','Latte',15)
insert into ProductMaster values(3,'Fast-Food','Burger',20)
insert into ProductMaster values(4,'Accessories','Air-Pods',25)
insert into ProductMaster values(5,'Accessories','Watch',25)
insert into ProductMaster values(6,'Accessories','Perfume',25)
insert into ProductMaster values(7,'Cold-Drinks','Pepsi',25)

select * from productMaster


create table dailySales
(
	salesId int primary key identity,
	productId int,
	salesQty int,
	salesPrice int,
	constraint fk_productId foreign key(productId) references ProductMaster
)
insert into dailySales values(3,2,10)
insert into dailySales values(1,2,10)
insert into dailySales values(2,2,10)
insert into dailySales values(3,2,10)
insert into dailySales values(3,2,10)
insert into dailySales values(3,2,10)
insert into dailySales values(2,2,10)
insert into dailySales values(1,2,10)
insert into dailySales values(1,2,10)
insert into dailySales values(1,2,10)