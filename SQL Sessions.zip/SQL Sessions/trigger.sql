create trigger trg_employeeinfo
on employeeInfo
for insert
as
begin
	--check the condition here
	if(DATEPART(WEEKDAY,getdate()) = 6)
	begin 
		throw 50005,'Sorry you cannot add new employee on friday',1
	end
end

select* from employeeInfo
insert into employeeInfo values(500,'Nik','Trainer',6000,2)

-------------------------------------------------------------------------------------
create table stockInfo
(
	stockId int primary key,
	stockName varchar(20),
	stockPrice int,
	stockAvailableQty int)

insert into stockInfo values(101,'Pepsi',50,100)
insert into stockInfo values(102,'Hotdog',100,100)
insert into stockInfo values(103,'Chowmein',2,100)

select * from stockInfo


create table dailySales
(
	saleId int primary key,
	pId int,
	saleQty int,
	constraint fk_pId foreign key(pId) references stockInfo
)

alter trigger trg_dailySales
on dailySales
after insert 
as
begin
	declare @pid int
	declare @saleQty int
	set @pid = (select pId from inserted i)
	set @saleQty = (select saleQty from inserted i)

	update stockinfo set stockAvailableQty=stockAvailableQty - @saleQty where stockId = @pid
end

select * from stockInfo
select * from dailysales

insert into dailysales values(1,103,8)












select * from stockinfo
select * from dailysales

insert into dailysales values(2,101,27)







