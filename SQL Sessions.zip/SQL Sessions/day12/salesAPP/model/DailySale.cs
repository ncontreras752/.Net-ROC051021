﻿using System;
using System.Collections.Generic;

#nullable disable

namespace salesAPP.model
{
    public partial class DailySale
    {
        public int SalesId { get; set; }
        public int? ProductId { get; set; }
        public int? SalesQty { get; set; }
        public int? SalesPrice { get; set; }

        public virtual ProductMaster Product { get; set; }
    }
}
