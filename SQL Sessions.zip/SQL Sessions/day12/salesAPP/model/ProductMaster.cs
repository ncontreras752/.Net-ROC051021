﻿using System;
using System.Collections.Generic;

#nullable disable

namespace salesAPP.model
{
    public partial class ProductMaster
    {
        public ProductMaster()
        {
            DailySales = new HashSet<DailySale>();
        }

        public int ProductId { get; set; }
        public string ProductCategory { get; set; }
        public string ProductName { get; set; }
        public int? ProductTax { get; set; }

        public virtual ICollection<DailySale> DailySales { get; set; }
    }
}
