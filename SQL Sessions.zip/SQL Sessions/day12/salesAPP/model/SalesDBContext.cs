﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace salesAPP.model
{
    public partial class SalesDBContext : DbContext
    {
        public SalesDBContext()
        {
        }

        public SalesDBContext(DbContextOptions<SalesDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DailySale> DailySales { get; set; }
        public virtual DbSet<ProductMaster> ProductMasters { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=trainer-vm;database=SalesDB; integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<DailySale>(entity =>
            {
                entity.HasKey(e => e.SalesId)
                    .HasName("PK__dailySal__E31CBAB0C93851B7");

                entity.ToTable("dailySales");

                entity.Property(e => e.SalesId).HasColumnName("salesId");

                entity.Property(e => e.ProductId).HasColumnName("productId");

                entity.Property(e => e.SalesPrice).HasColumnName("salesPrice");

                entity.Property(e => e.SalesQty).HasColumnName("salesQty");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.DailySales)
                    .HasForeignKey(d => d.ProductId)
                    .HasConstraintName("fk_productId");
            });

            modelBuilder.Entity<ProductMaster>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__ProductM__2D10D16A8AD1259F");

                entity.ToTable("ProductMaster");

                entity.Property(e => e.ProductId)
                    .ValueGeneratedNever()
                    .HasColumnName("productId");

                entity.Property(e => e.ProductCategory)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("productCategory");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("productName");

                entity.Property(e => e.ProductTax).HasColumnName("productTax");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
