﻿using System;
using System.Linq;
using salesAPP.model;
namespace salesAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // display the list of producds from productMaster
            //1. create a new object of your dbContext class

            //  var salesDBCObj = new SalesDBContext();

            // //2. fire your query
            // var myProducts = from p in salesDBCObj.ProductMasters
            //                 where p.ProductTax < 20
            //                 select p;

            // //3. display  your data
            // foreach (var item in myProducts)
            // {
            //     System.Console.WriteLine(item.ProductId + " : " + item.ProductName);
            // }


//Add  new Product to database 

        //  var salesDBCObj = new SalesDBContext();

        //  var newProduct = new ProductMaster();
        //  newProduct.ProductId = 8;
        //  newProduct.ProductName = "MacBook Pro";
        //  newProduct.ProductTax = 30;
        //  newProduct.ProductCategory = "Laptop";

        //  salesDBCObj.ProductMasters.Add(newProduct);
        //  salesDBCObj.SaveChanges();


//delete the product
            // var salesDBCObj = new SalesDBContext();

            // System.Console.WriteLine("Please Enter product id to be deleted");
            // int productId =Convert.ToInt32(Console.ReadLine());
            // var productToDelete = salesDBCObj.ProductMasters.Find(productId);

            // salesDBCObj.ProductMasters.Remove(productToDelete);
            // salesDBCObj.SaveChanges();
            // System.Console.WriteLine("Product Delete Successfully");


//update the product
        var salesDBCObj = new SalesDBContext();
        var productToUpdate = salesDBCObj.ProductMasters.Find(1);

            productToUpdate.ProductName = "Appy-Fizz";
            productToUpdate.ProductTax = 18;

            bool confirm = false;
            System.Console.WriteLine("Are you sure you want to Apply Changes");
            confirm = Convert.ToBoolean(Console.ReadLine());

            if(confirm)
            {
                salesDBCObj.SaveChanges();
            }
            
           
            System.Console.WriteLine("Product Updated Successfully");

        }
    }
}
