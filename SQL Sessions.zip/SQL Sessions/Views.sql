use bankingDB

select * from employeeInfo
select * from deptInfo


--this query revels the names  of both the tables
--this also revels the bonus calculation formula

create view EmployeeView
as
select empNo as [Employee Number],
	   CONCAT(empName,'-',empDesignation) as Employee,
	     empSalary * 0.1 as Bonus,
		 deptName as [Works In],
		 depHead as [Reports To]
		 from employeeInfo join deptInfo
		 on empDept = deptNo

		 --this view name will be shared with Fromtend developer, report developer, outsider
		 --the other person
		 --here he will not be able to view the real name of the column
		 --real name of the tbales, calculations, join type
		 select * from EmployeeView 

		 create view CTCInfo
		 as
		select empName as Employee,
		empSalary as MontlyPay,
		empSalary * 0.1 as Bonus,
		empSalary * 0.15 as [Food Copouns],
		empSalary * 12 as [Annual Pay],
		(empSalary + (empSalary * 0.1) + (empSalary * 0.15)) * 12 as [Gross Salary],
		((empSalary + (empSalary * 0.1) + (empSalary * 0.15)) * 12) * 8 /100 as Tax
		from employeeInfo

		select * from CTCInfo

			select CTCInfo.Bonus, CTCInfo.Bonus + 250 as [Extra Bonus]from CTCInfo
			select UPPER(EmployeeView.Employee) from EmployeeView

	select * from employeeInfo

	create view [Employee Ratings]
	as
	select empName as Employee,
		   empSalary as Salary,
		   case empSalary 
			when 200000 then '*****'
			when 50000 then '***'
			when 45000 then '*'
			end 
			as [Ratings]
		from employeeInfo

		select * from [Employee Ratings]

		select * from deptInfo


		alter  view EmpSOLView
		as
		select
		empName as Employee,
		empDesignation as [Working as] ,
		empSalary As Pay,
		EmpSalary as Bonus,
		deptNo as [Department No],
		deptName [Department Name],
		deptLocation as [Located At],
		case deptInfo.deptLocation 
			when 'NYC' then 'Excellent'
			when 'San Fransisco' then 'High'
			when 'California' then 'Average'
			else 'Poor'
		end as [Standard of Living]
		from 
		employeeInfo join deptInfo
		on employeeInfo.empDept = deptInfo.deptNo

		select * from EmpSOLView
		


		select * from deptInfo

		alter view myView as 
		select empNo, empName from employeeInfo where empNo > 20
		order by empName desc


		select * from myview


		select * from employeeInfo

			select count(empNo) AS Total from employeeInfo
			select sum(empSalary) as [Total Salary Paid],
				   min(empsalary) as Minimum,
				   max(empSalary) as Maximun,
				   avg(empSalary) as Average from employeeInfo

			--who has the max salary 

			
			select * from employeeInfo where empSalary = 205000
			--we wil want the max value to be dynamic, we do not wish to change our query always
			--thus we can use sub-query
			--sub-query
			select * from employeeInfo where empSalary = (select max(empSalary) from employeeInfo)



			insert into employeeInfo values(42,'Penny','Software engg',208000,3)
			update employeeInfo set empSalary = empSalary + 350000 where empDept = 1

			select sum(empSalary) from employeeInfo
						
			select distinct empDesignation from employeeInfo

			--we need a biforcation of this total salary for every designation
			--this can be achived using group by clause
			select count(empSalary), empDesignation from employeeInfo
				group by empDesignation

			select count(empNo), isnull(empdept, 0) from employeeInfo
				group by empdept


			create view EmployeeCountPerLocation
			as
			select count(empNo) as Pay,isnull(deptLocation,'Not Assigned') as City from 
			employeeInfo left join deptInfo
			on employeeInfo.empDept = deptInfo.deptNo
			group by deptLocation

			select * from EmployeeCountPerLocation
			