--lets not pass a parameter -- parameterless proc
create procedure proc_updateSalary
as
begin
	update employeeInfo set empSalary = empSalary + 125
end

exec proc_updateSalary

select * from employeeInfo
-----------------------------------------------------------------------------------------
create procedure proc_updateSalary2(@amount int)
as
begin
	update employeeInfo set empSalary = empSalary + @amount
end

execute proc_updateSalary2 870

----------------------------------------------------------
create procedure proc_deleteEmployee(@p_empNo int)
as
begin
	delete from employeeInfo where empNo =@p_empNo
end

execute proc_deleteEmployee 21

-----------------------------------------------------------------------
select * from employeeInfo

create procedure proc_addEmployee
(
	@p_empNo int, 
	@p_empName varchar(20),
	@p_empDesignation varchar(20),
	@p_empSalary int,
	@p_empDept int
)
as
begin
		--declare variables
		--use if considitions, switch case, calculation, formatting, fire a sql select etc.
		insert into employeeInfo values(@p_empNo,upper(@p_empName),@p_empDesignation,@p_empSalary,
											@p_empDept)
end

exec proc_addEmployee 50,'Michelle','HR',6000,2
select * from employeeInfo

--------------------------------------------------------------------------------------------


create table newAccountsInfo
(
	accNo int primary key,
	accName varchar(20),
	accType varchar(20),
	accGender varchar(6),
	accBalance int
)

alter table newAccountsInfo add accEmail varchar(40)
select * from newAccountsInfo

create procedure proc_addNewAccount(@accNo int, @accName varchar(20),
									@accType varchar(20),@accGender varchar(20),
									@accBalance int)
as
begin
	
	declare @accEmail varchar(40) =lower(concat(@accName,'.',left(@accType,2),'@mybank.com'))
		if(@accGender = 'Male')
		begin
			set @accName = 'Mr.' + @accName
		end
		else if(@accGender = 'Female')
		begin
			set @accName = 'Ms.' + @accName
		end		

		insert into newAccountsInfo values(@accNo,@accName,@accType,upper(@accGender),@accBalance,@accEmail)
end



select * from newAccountsInfo

exec proc_addNewAccount 101,'Joseph','Savaings','Male',6000
exec proc_addNewAccount 102,'Stella','Credit','Female',15000

------------------------------------------------------------------------------------------------------




alter procedure proc_addNewAccount2(@accNo int output, @accName varchar(20),
									@accType varchar(20),@accGender varchar(20),
									@accBalance int)
as
begin

	set @accNo = (select max(accno) + 1 from newAccountsInfo)
	
	declare @accEmail varchar(40) =lower(concat(@accName,'.',left(@accType,2),'@mybank.com'))
		if(@accGender = 'Male')
		begin
			set @accName = 'Mr.' + @accName
		end
		else if(@accGender = 'Female')
		begin
			set @accName = 'Ms.' + @accName
		end		

		insert into newAccountsInfo values(@accNo,@accName,@accType,upper(@accGender),@accBalance,@accEmail)
end











declare @newNumberResult int
exec proc_addNewAccount2 @newNumberResult output,'Angel','Credit','Female',12000
print concat('Account Added Successfully, New Account Number is : ',@newNumberResult)





select * from newaccountsinfo




create table Login
(
	userName varchar(20) primary key,
	password varchar(20),
	status varchar(30)
)

insert into Login values('Angel','pass@1234','Active')
insert into Login values('Raquel','pass@3698','Active')
insert into Login values('Monica','pass@9632','Active')

create procedure proc_Login(@p_userName varchar(20),@p_password varchar(20), @p_result varchar(20) output)
as
begin
	declare @count int = (select count(*) from Login where userName = @p_userName and password=@p_password and status = 'Active')
	if(@count = 1)
	begin
		set @p_result = 'Login Successful'
	end
	else if(@count = 0)
	begin
		set @p_result = 'Login Failed'
	end
end

declare @try_login varchar(20)
exec proc_Login 'Angel','pass@1234',@try_login output
print @try_login


-----------------------------------------------------------------------------------------
	create  table Products
	(
		pId int primary key,
		pName varchar(20),
		pCategory varchar(20),
		pPrice int,
		pDiscount int,
		
		constraint chk_category check(pCategory in ('Fast-Food', 'Cold-Drink','Hot-Beverage'))
	)		

	add a check constraint, category can only be
		'Fast-Food', 'Cold-Drink','Hot-Beverage'

	you need to create a procedure to add a new product in this table
		take the below inputs from user
			pId, pName, pCategory, pPrice
		procedure should insert dicount based on the pCategory
			fast-food - 5
			Cold-Drink - 8
			Hot-Beverage - 10
	create procedure proc_newProduct(@pId int, @pName varchar(20), @pCategory varchar(20), @pPrice int)
	as
	begin
		declare @dicount int = 0
		if(@pCategory = 'Fast-Food')
		begin
			set @dicount = @pPrice * 5 /100
		end

		if(@pCategory = 'Cold-Drink')
		begin
			set @dicount = @pPrice * 8 /100
		end

		if(@pCategory = 'Hot-Beverage')
		begin
			set @dicount = @pPrice * 10 /100
		end

		insert into products values(@pId,@pName,@pCategory,@pPrice,@dicount)
	end

	select * from products

	exec proc_newProduct 101,'Pepsi','Cold-Drink',50
	exec proc_newProduct 102,'Starbucks Coffe Latte','Hot-Beverage',200
	exec proc_newProduct 103,'Hot-dog','Fast-food',70









