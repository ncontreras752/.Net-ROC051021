alter function Greetings(@name varchar(20)) returns varchar(30)
as
begin
	return 'Hello and Welcome ' + @name
end

select dbo.Greetings('Nikhil') as MyMessage

select dbo.greetings(deptLocation) as Greet from deptInfo
-----------------------------------------------------

---------------------------------------------
create function addNumbers(@num1 int, @num2 int) returns int
as
begin
	return @num1 + @num2
end

select dbo.addNumbers(30,80)
select dbo.addNumbers(empSalary,250) from employeeInfo
------------------------------------------------------------------------------------------------------

create function simpleIntrest(@investment int, @years int, @intrestRate int)
returns int
as
begin
	declare @profit int = (@investment * @intrestRate / 100) * @years
	return @profit
end

select dbo.simpleIntrest (10000,3,8) as Bonus

-------------------------------------------------------------------------------------
create function getFeedback(@number int) returns varchar(20)
as
begin
	if(@number < 20)
	begin
		return 'Number is Poor'
	end	
		return 'Number is Good'
end
select dbo.getFeedback(15)

-------------------------------------------------
create function getFeedback2(@number int) returns varchar(20)
as
begin
	if(@number > 5 and @number < 20)
	begin
		return 'Number is Poor'
	end	
	else if (@number >20 and @number < 50)
	begin
		return 'Number is Average'
	end
	else if (@number >50 and @number < 75)
	begin
		return 'Number is Good'
	end
	else if (@number >75 and @number < 100)
	begin
		return 'Number is Very Good'
	end
	else if(@number > 100)
	begin
		return 'Excellent Number'
	end
		
		return 'Number is Invalid'
	
end






select dbo.getFeedback2(-10)





alter function getEmailAddress(@p_empNo int) returns varchar(60)
as
begin
	declare @v_empName varchar(20) = (select empName from employeeInfo where empNo = @p_empNo)
	declare @v_empDesignation varchar(20) = (select empDesignation from employeeInfo where empNo = @p_empNo)

	if( len(@v_empName) > 2)
	begin
	declare @email varchar(60) = lower(concat(@v_empName,'.',left(@v_empDesignation,2),'@myorg.com'))
	return @email
	end

	return 'Invalid Employee Number'
end

	select dbo.getEmailAddress(35)

	