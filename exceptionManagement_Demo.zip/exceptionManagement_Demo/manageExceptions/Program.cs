﻿using System;

namespace manageExceptions
{
    class Program
    {
        static void Main(string[] args)
        {

            // try
            // {

            //     Console.WriteLine("Please Enter First  Number");
            //     int num1 = Convert.ToInt32(Console.ReadLine());
            //     Console.WriteLine("Please Enter second Number");
            //     int num2 = Convert.ToInt32(Console.ReadLine());
            //     int divisionResult = num1 / num2;
            //     System.Console.WriteLine("Division Result is : " + divisionResult);            
            // }
            // catch(DivideByZeroException divideByZeroObj)
            // {
            //         // System.Console.WriteLine(divideByZeroObj.Message);
            //         System.Console.WriteLine("You cannot Divide a Number by Zero");
            // }
            // catch(FormatException formatObj)
            // {
            //             System.Console.WriteLine("Sorry please enter value only in Digits");
            // }
            // catch(Exception es)
            // {
            //     // System.Console.WriteLine(es.Message);       
            //     System.Console.WriteLine("Something went wrong, please try again");         
            // }
            // finally
            // {
            //     System.Console.WriteLine("Thank you for using my APP");
            // }

            // Console.ReadLine();



    try
    {
            System.Console.WriteLine("Enter Account Number");
            int v_accNo = Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("Enter Account Name");
            string v_accName = Console.ReadLine();
            System.Console.WriteLine("Enter Account Balance");
            double v_accBalance = Convert.ToDouble(Console.ReadLine());

            var accObj = new Accounts(v_accNo,v_accName,v_accBalance);

            System.Console.WriteLine("Thank you for opening the account, Its a Success !!");

            System.Console.WriteLine("Do you wish to Widraw ? Press 1 if yes");
            int choice = Convert.ToInt32(Console.ReadLine());
            if(choice == 1)
            {
                System.Console.WriteLine("Enter the amount to widraw, Current Balance " + accObj.accBalance);
                int v_wAmount = Convert.ToInt32(Console.ReadLine());
                accObj.Widraw(v_wAmount);
                System.Console.WriteLine("Widrawal successull, current balance " + accObj.accBalance);

            }
    }
    catch(FormatException es)
    {
            System.Console.WriteLine("Please enter value in correct format only");
    }
    catch(Exception es)
    {
        System.Console.WriteLine(es.Message);
    }
    finally
    {
        System.Console.WriteLine("Thank you for Banking");
    }
            Console.ReadLine();

        }
    }
}
