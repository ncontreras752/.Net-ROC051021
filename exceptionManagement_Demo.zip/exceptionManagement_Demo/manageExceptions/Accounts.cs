using System;
namespace manageExceptions
{
    class Accounts
    {
        public int accNo { get; set; }
        public string accName { get; set; }
        public double accBalance { get; set; }
        public Accounts(int p_accNo, string p_accName, double p_accBalance)
        {
            if(p_accNo < 0)
            {
                throw new Exception("Account Number should be greater than zero");
            }
            if(p_accName.Length < 3 || p_accName.Length > 15)
            {
                throw new Exception("Name must be between 3 and 15 characters only");
            }
            if(p_accBalance < 500 || p_accBalance > 12000)
            {
                throw new Exception("Initial balance can only be between $500 and $12000");
            }
            accNo = p_accNo;
            accName = p_accName;
            accBalance = p_accBalance;    
        }

        public double Widraw(int p_amount)
        {
            if(p_amount < 0)
            {
                        throw new Exception("Sorry you cannot widraw a negative value");
            }
            if(p_amount > accBalance)
            {
                    throw new Exception("Insufficient Funds");
            }
            if(p_amount < 100 || p_amount > 50000)
            {
                    throw new Exception("You can widraw only between 100 and 50000 in a transation");
            }
            accBalance = accBalance - p_amount;
            return accBalance;
        }
    }
}