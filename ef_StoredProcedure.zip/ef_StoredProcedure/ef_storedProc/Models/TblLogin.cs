﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ef_storedProc.Models
{
    public partial class TblLogin
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
