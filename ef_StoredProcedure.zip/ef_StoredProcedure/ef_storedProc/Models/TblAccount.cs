﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ef_storedProc.Models
{
    public partial class TblAccount
    {
        public int AccNo { get; set; }
        public string AccName { get; set; }
        public string AccType { get; set; }
        public int? AccBalance { get; set; }
    }
}
