﻿using System;
using ef_storedProc.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

namespace ef_storedProc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var bankingDBObj = new bankingProjectDBContext();
        

//delete Account
        // var deleteResult = bankingDBObj.Database.ExecuteSqlRaw("proc_deleteAccount 504");
        // if(deleteResult > 0)
        // {
        //     System.Console.WriteLine("Account Deleted Successfully");
        // }
        // else
        // {
        //     System.Console.WriteLine("Wrong Account number");
        // }
//update Account
        // var updateResult = bankingDBObj.Database.ExecuteSqlRaw("proc_updateAccount 996,[Nikhil Shah]");
        // if(updateResult >0)
        // {
        //     System.Console.WriteLine("Account Updated Successfully");
        // }
        // else
        // {
        //     System.Console.WriteLine("Wrong Account Number");
        // }
//transfer Amount
        // var transferResult  = bankingDBObj.Database.ExecuteSqlRaw("proc_transfer 103,502,4000");
        //     if(transferResult > 0)
        //     {
        //         System.Console.WriteLine("Transfer Successfull");
        //     }
        //     else
        //     {
        //         System.Console.WriteLine("Invalid Details");
        //     }
//Add Account - output parameter

        // var newAccountNo = new SqlParameter(){ 
        //                                         ParameterName="accNo",
        //                                         DbType = System.Data.DbType.Int32,
        //                                         Direction = System.Data.ParameterDirection.Output };

        // var addResult = bankingDBObj.Database.ExecuteSqlRaw("proc_addAccount Jennifer,Credit,25000,@accNo OUTPUT",newAccountNo);

        // System.Console.WriteLine("Account Added Successfully, New account No is " + newAccountNo.Value);

//Login
        var loginOutput = new SqlParameter(){
                                    ParameterName = "result", 
                                    DbType = System.Data.DbType.String,Size=20,
                                    Direction = System.Data.ParameterDirection.Output
        };
        var loginResult = bankingDBObj.Database.ExecuteSqlRaw("proc_Login Nikhil,nikhil@1234,@result output",loginOutput);
        System.Console.WriteLine(loginOutput.Value);
        }
    }
}
